package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.fms.dto.Feedback;
import com.cg.fms.exception.FMSException;
import com.cg.fms.util.ApplicationLogger;
import com.cg.fms.util.DBUtil;

public class FeedbackDaoImpl implements FeedbackDao {

	Connection con;
	Logger feedbackLogger = null;

	public FeedbackDaoImpl() {
		con = DBUtil.getConnection();
		feedbackLogger = ApplicationLogger.getLogger(FeedbackDaoImpl.class);
	}

	//This method return all feedbacks for a particular participant
	@Override
	public ArrayList<Feedback> getFeedbackByParticipantId(int id) throws FMSException {
		ArrayList<Feedback> list = new ArrayList<Feedback>();
		Feedback ref = null;
		String qry = "SELECT * FROM  FEEDBACK_MASTER WHERE PARTICIPANT_ID=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			feedbackLogger.info("Fetch feedback for a given Participant");
			while (rs.next()) {

				int tId = rs.getInt(1);
				int pId = rs.getInt(2);
				int presentation = rs.getInt(3);
				int clarifyDoubts = rs.getInt(4);
				int timeMgt = rs.getInt(5);
				int hndOut = rs.getInt(6);
				int hwSw = rs.getInt(7);
				String sugg = rs.getString(8);
				String comment = rs.getString(9);
				ref = new Feedback(tId, pId, presentation, clarifyDoubts, timeMgt, hndOut, hwSw, sugg, comment);
				list.add(ref);

			}
		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;

	}
	
	//This method return all feedbacks for a particular training
	@Override
	public ArrayList<Feedback> getFeedbackByTrainingId(int id) throws FMSException {
		ArrayList<Feedback> list = new ArrayList<Feedback>();
		Feedback ref = null;
		String qry = "SELECT * FROM  FEEDBACK_MASTER WHERE TRAINING_CODE=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			feedbackLogger.info("Fetch  Feedback for given TrainingCode");
			while (rs.next()) {

				int tId = rs.getInt(1);
				int pId = rs.getInt(2);
				int presentation = rs.getInt(3);
				int clarifyDoubts = rs.getInt(4);
				int timeMgt = rs.getInt(5);
				int hndOut = rs.getInt(6);
				int hwSw = rs.getInt(7);
				String sugg = rs.getString(8);
				String comment = rs.getString(9);
				ref = new Feedback(tId, pId, presentation, clarifyDoubts, timeMgt, hndOut, hwSw, sugg, comment);
				list.add(ref);

			}
		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;

	}

	//This method return all feedbacks
	@Override
	public ArrayList<Feedback> getAllFeedbacks() throws FMSException {

		String qry = "SELECT * FROM FEEDBACK_MASTER";
		ArrayList<Feedback> list = new ArrayList<Feedback>();
		Feedback ref = null;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			feedbackLogger.info("Fetch All Feedbacks");
			while (rs.next()) {

				int tId = rs.getInt(1);
				int pId = rs.getInt(2);
				int presentation = rs.getInt(3);
				int clarifyDoubts = rs.getInt(4);
				int timeMgt = rs.getInt(5);
				int hndOut = rs.getInt(6);
				int hwSw = rs.getInt(7);
				String sugg = rs.getString(8);
				String comment = rs.getString(9);
				ref = new Feedback(tId, pId, presentation, clarifyDoubts, timeMgt, hndOut, hwSw, sugg, comment);
				list.add(ref);

			}

		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;
	}
	
	//This method add the given feedback to database
	@Override
	public int addFeedback(Feedback feedback) throws FMSException {
		int row;
		String qry = "INSERT INTO FEEDBACK_MASTER VALUES(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, feedback.getTrainingCode());
			pstmt.setInt(2, feedback.getParticipantId());
			pstmt.setInt(3, feedback.getPresentationCommunication());
			pstmt.setInt(4, feedback.getClarifyDoubts());
			pstmt.setInt(5, feedback.getTimeManagement());
			pstmt.setInt(6, feedback.getHandOut());
			pstmt.setInt(7, feedback.getHwSwNetwork());
			pstmt.setString(8, feedback.getComments());
			pstmt.setString(9, feedback.getSuggestions());

			row = pstmt.executeUpdate();
			feedbackLogger.info("Feedback Inserted");

		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return row;
	}
	
	//This method provides all the defaulters feedback
	@Override
	public ArrayList<Feedback> getDefaulters() throws FMSException {
		String qry = "SELECT * FROM FEEDBACK_MASTER where FB_Prs_comm is null or FB_Clrfy_dbts is null or FB_TM is null or FB_Hnd_out is null or FB_Hw_Sw_Ntwrk is null";
		ArrayList<Feedback> list = new ArrayList<Feedback>();
		Feedback ref = null;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			feedbackLogger.info("Fetch All incompleted Feedbacks");
			while (rs.next()) {

				int tId = rs.getInt(1);
				int pId = rs.getInt(2);
				int presentation = rs.getInt(3);
				int clarifyDoubts = rs.getInt(4);
				int timeMgt = rs.getInt(5);
				int hndOut = rs.getInt(6);
				int hwSw = rs.getInt(7);
				String sugg = rs.getString(8);
				String comment = rs.getString(9);
				ref = new Feedback(tId, pId, presentation, clarifyDoubts, timeMgt, hndOut, hwSw, sugg, comment);
				list.add(ref);

			}

		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;
	}
	
	//This method provides all the defaulters feedback for a given month
	@Override
	public ArrayList defaultersFeedback(int month) throws FMSException {
		ArrayList list = new ArrayList();
		String qry = "select a.training_code,faculty_code,start_date,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hnd_out,fb_hw_sw_ntwrk from Training_master a inner join Feedback_master b on a.training_code=b.training_code where (extract( MONTH from start_date)=?) and (fb_prs_comm is null or fb_clrfy_dbts is null or  fb_tm is null or fb_hnd_out is null or fb_hw_sw_ntwrk is null)";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, month);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				int trainingCode = rs.getInt(1);
				int facultyCode = rs.getInt(2);
				LocalDate startDate = rs.getDate(3).toLocalDate();
				int presentation = rs.getInt(4);
				int clarifyDoubts = rs.getInt(5);
				int timeMgt = rs.getInt(6);
				int hndOut = rs.getInt(7);
				int hwSw = rs.getInt(8);
				list.add(trainingCode);
				list.add(facultyCode);
				list.add(startDate);
				list.add(presentation);
				list.add(clarifyDoubts);
				list.add(timeMgt);
				list.add(hndOut);
				list.add(hwSw);

			}
		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;

	}
	
	@Override
	public ArrayList joinTrainingWithFeed(int month) throws FMSException {
		ArrayList list = new ArrayList();
		String qry = "select a.training_code,faculty_code,start_date,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hnd_out,fb_hw_sw_ntwrk from Training_master a inner join Feedback_master b on a.training_code=b.training_code where extract( MONTH from start_date)=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, month);
			ResultSet rs = pstmt.executeQuery();
			feedbackLogger.info("Average feedback for a given month");
			while (rs.next()) {
				int trainingCode = rs.getInt(1);
				int facultyCode = rs.getInt(2);
				LocalDate startDate = rs.getDate(3).toLocalDate();
				int presentation = rs.getInt(4);
				int clarifyDoubts = rs.getInt(5);
				int timeMgt = rs.getInt(6);
				int hndOut = rs.getInt(7);
				int hwSw = rs.getInt(8);
				list.add(trainingCode);
				list.add(facultyCode);
				list.add(startDate);
				list.add(presentation);
				list.add(clarifyDoubts);
				list.add(timeMgt);
				list.add(hndOut);
				list.add(hwSw);

			}

		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;
	}

	//This method provides all the feedback for a faculty for given month
	@Override
	public ArrayList facultyFeedback(int id, int month) throws FMSException {
		ArrayList list = new ArrayList();
		String qry = "select a.training_code,start_date,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hnd_out,fb_hw_sw_ntwrk from Training_master a inner join Feedback_master b on a.training_code=b.training_code where (extract( MONTH from start_date)=?) and faculty_code=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, month);
			pstmt.setInt(2, id);
			ResultSet rs = pstmt.executeQuery();
			feedbackLogger.info("Feedback for given FacultyId and Month");
			while (rs.next()) {
				int trainingCode = rs.getInt(1);
				LocalDate startDate = rs.getDate(2).toLocalDate();
				int presentation = rs.getInt(3);
				int clarifyDoubts = rs.getInt(4);
				int timeMgt = rs.getInt(5);
				int hndOut = rs.getInt(6);
				int hwSw = rs.getInt(7);
				list.add(trainingCode);
				list.add(startDate);
				list.add(presentation);
				list.add(clarifyDoubts);
				list.add(timeMgt);
				list.add(hndOut);
				list.add(hwSw);

			}

		} catch (Exception e) {
			throw new FMSException(e.getMessage());
		}
		return list;

	}
	
	//This method provides all the feedback for given participant id and training code
	@Override
	public Feedback findFeedbackByPIdAndTCode(int pId, int tCode) throws FMSException {
		// TODO Auto-generated method stub
		Feedback feedback = null;
		try {
			String query = "SELECT * FROM feedback_master WHERE training_code=? AND participant_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, tCode);
			ps.setInt(2, pId);
			ResultSet rs = ps.executeQuery();
			feedbackLogger.info("Feedback for trainingCode =" + tCode + "ParticipantId =" + pId);
			if (rs.next()) {
				feedback = new Feedback(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getString(8), rs.getString(9));
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new FMSException(e.getMessage());
		}
		return feedback;
	}
}
