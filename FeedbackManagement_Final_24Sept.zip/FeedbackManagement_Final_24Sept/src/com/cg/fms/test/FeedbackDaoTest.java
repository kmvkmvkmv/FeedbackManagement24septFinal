package com.cg.fms.test;

import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.fms.dao.FeedbackDao;
import com.cg.fms.dao.FeedbackDaoImpl;
import com.cg.fms.dto.Feedback;
import com.cg.fms.exception.FMSException;



public class FeedbackDaoTest {
	static  FeedbackDao obj = null;
	
	@BeforeClass
	public static void initClass() {
		obj = new FeedbackDaoImpl();
	}
	
	// Checks for normal insertion in databse
	/*@Test
	public void addFeedbackTest1() {
		try {
			Feedback feedback = new Feedback(10001, 10004, 4, 3, 2, 1, 4, "pathak comments", "pathak suggestion");
			Assert.assertEquals(1, obj.addFeedback(feedback));
		} catch (FMSException e) {
		}
	}*/
	
	//Wrong foreign key (training code) inserted
	/*
	@Test(expected=FMSException.class)
	public void addFeedbackTest2() throws FMSException {
			Feedback feedback = new Feedback(2514, 10004, 4, 3, 2, 1, 4, "pathak comments", "pathak suggestion");
			Assert.assertEquals(1, obj.addFeedback(feedback));
		
	}*/
	
	@Test(expected=FMSException.class)
	public void addFeedbackTest3() throws FMSException {
			Feedback feedback = new Feedback(10001, 25365, 4, 3, 2, 1, 4, "pathak comments", "pathak suggestion");
			Assert.assertEquals(1, obj.addFeedback(feedback));
		
	}
	@Test
	public void facultyFeedbackTest1() throws FMSException {
		ArrayList arr=obj.facultyFeedback(10001, 8);
		Assert.assertEquals(2*7, arr.size());
		
	}
	
	@Test
	public void facultyFeedbackTest2() throws FMSException {
		ArrayList arr=obj.facultyFeedback(10001, 13);
		Assert.assertEquals(0, arr.size());
		
	}
	
	@Test
	public void facultyFeedbackTest() throws FMSException {
		ArrayList arr=obj.facultyFeedback(9856, 9);
		Assert.assertEquals(0, arr.size());
		
	}
	
	
	
	
}
