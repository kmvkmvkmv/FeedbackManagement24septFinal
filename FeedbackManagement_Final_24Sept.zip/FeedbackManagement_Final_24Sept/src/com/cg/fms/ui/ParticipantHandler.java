package com.cg.fms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.dto.Course;
import com.cg.fms.dto.Employee;
import com.cg.fms.dto.Feedback;
import com.cg.fms.dto.ParticipantEnrollment;
import com.cg.fms.dto.Training;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.CourseService;
import com.cg.fms.service.CourseServiceImpl;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.ParticipantEnrollmentService;
import com.cg.fms.service.ParticipantEnrollmentServiceImpl;
import com.cg.fms.service.TrainingService;
import com.cg.fms.service.TrainingServiceImpl;

public class ParticipantHandler {
	Employee participant = null;
	CourseService courseService = null;
	ParticipantEnrollmentService partcipantEService = null;
	TrainingService trainingService = null;
	FeedbackService feedbackService = null;

	Scanner sc = new Scanner(System.in);

	public ParticipantHandler(Employee employee) {
		super();
		participant = employee;
		courseService = new CourseServiceImpl();
		partcipantEService = new ParticipantEnrollmentServiceImpl();
		trainingService = new TrainingServiceImpl();
		feedbackService = new FeedbackServiceImpl();
	}

	public void start() throws FMSException {

		System.out.println("*****************************************");
		System.out.println("Welcome " + participant.getEmployeeName());
		System.out.println("You are logged in as PARTICIPANT");
		// System.out.println("What do you want to do");

		ArrayList<ParticipantEnrollment> participantList = partcipantEService
				.getParticipantEnrollmentByParticipantId(participant.getEmployeeId());

		ArrayList<Training> trainingsAssigned = new ArrayList<>();

		for (ParticipantEnrollment enrollment : participantList) {
			trainingsAssigned.add(trainingService.getTrainingById(enrollment.getTrainingCode()));
		}

		ArrayList<Course> courseList = new ArrayList<>();

		for (Training training : trainingsAssigned) {
			courseList.add(courseService.getCourseById(training.getCourseCode()));
		}

		if (courseList.size() == 0) {
			System.out.println("Sorry! you are not enrolled with any course");
			System.out.println("Logging off....");
			return;
		}
		System.out.println("List of courses you are enrolled with : ");

		for (int i = 0; i < courseList.size(); i++) {
			System.out.println("Training Code : " + trainingsAssigned.get(i).getTrainingCode() + ", Name : "
					+ courseList.get(i).getCourseName());
		}
		while(true) {
			System.out.println("What do you want to do?");
			System.out.println("1.Add Feedback\n2.Logout");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Please enter the training code : ");
				int trainingCode = sc.nextInt();
				if (!feedbackService.validateTrainingCode(trainingCode)) {
					System.out.println("Please enter valid training code");
					continue;
				}
				boolean available = false;
				for (Training training : trainingsAssigned) {
					if (training.getTrainingCode() == trainingCode) {
						available = true;
						break;
					}
				}
				if (available) {
					if (!alreadyGiven(trainingCode)) {
						Feedback feedback = takefeedback(trainingCode);

						int feedbackReceived = feedbackService.addFeedback(feedback);
						if (feedbackReceived == 1) {
							System.out.println("Thankyou for the feedback");
							break;
						} else {
							System.out.println("error in insertion, try again");
							continue;
						}
					} else {
						System.out.println("Alredy given feedback for this course");
					}
				} else {
					System.out.println("Wrong Training code entered, try again");
				}
				break;
				
			case 2:
				MainClass.main(null);
				
			default:
				break;
			}
		}
		
	

		// all menu items, switch case

	}

	private boolean alreadyGiven(int trainingCode) {
		// returns true if feedback is already given else false;

		try {
			Feedback fb = feedbackService.findFeedbackByPIdAndTCode(participant.getEmployeeId(), trainingCode);
			if (fb != null) {
				return true;
			}
		} catch (FMSException e) {
			System.out.println("Something Not Good");
		}

		return false;
	}

	public Feedback takefeedback(int trainingCode) throws FMSException {
		/*
		 * System.out.println("Enter training code : "); int trainingCode =
		 * sc.nextInt();
		 */
		/* System.out.println("Enter partcipant Id : "); */
		// int participantId = sc.nextInt();
		while(true) {

			int participantId = participant.getEmployeeId();
			System.out.println("5-Excellent: Ideal way of doing it\r\n" + 
					"4-Good: No pain areas or concern but could have been better\r\n" + 
					"3-Average: There are concerns but not significant\r\n" + 
					"2-Below Average: Needs improvement and is salvageable\r\n" + 
					"1-Poor: This way of doing things must change\r");
			System.out.println("Rate the presentation and communication of trainer from 0 - 5 : ");
			int presentationCommunication = sc.nextInt();
			if(!feedbackService.validateRating(presentationCommunication)) {
				System.out.println("Please enter value between 0 and 5");
				continue;
			}
			System.out.println("Rate the doubt clarification skill of trainer from 0 - 5 : ");
			int clarifyDoubts = sc.nextInt();
			if(!feedbackService.validateRating(clarifyDoubts)) {
				System.out.println("Please enter value between 0 and 5");
				continue;
			}
			System.out.println("Rate time management skill of trainer from 0 - 5 : ");
			int timeManagement = sc.nextInt();
			if(!feedbackService.validateRating(timeManagement)) {
				System.out.println("Please enter value between 0 and 5");
				continue;
			}
			System.out.println("Rate the hand out solving skill of trainer from 0 - 5 : ");
			int handOut = sc.nextInt();
			if(!feedbackService.validateRating(handOut)) {
				System.out.println("Please enter value between 0 and 5");
				continue;
			}
			System.out.println("Rate the harware and software network provided from 0 - 5 : ");
			int hwSwNetwork = sc.nextInt();
			if(!feedbackService.validateRating(hwSwNetwork)) {
				System.out.println("Please enter value between 0 and 5");
				continue;
			}
			sc.nextLine();
			System.out.println("Give additional comments if any : ");
			String comments = sc.nextLine();
			System.out.println("Give any suggestions : ");
			String suggestions = sc.nextLine();
	
			Feedback feedback = new Feedback(trainingCode, participantId, presentationCommunication, clarifyDoubts,
					timeManagement, handOut, hwSwNetwork, comments, suggestions);
	
			return feedback;
		}
	}
}
